package com.tint.cse.employeePay;

import java.sql.*;

public class Conn {
	private String url, uname, pass;

	Conn() {
		url = "jdbc:mysql://sql6.freemysqlhosting.net/sql6396949";
		uname = "sql6396949";
		pass = "CgYq7KPguF";
	}

	public Connection startConnection() {
		Connection con = null;
		try {
			con = DriverManager.getConnection(url, uname, pass);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return con;
	}

	public ResultSet getExecuteStatment(String query) {
		Connection con = startConnection();
		Statement st;
		ResultSet rs = null;
		try {
			st = con.createStatement();
			rs = st.executeQuery(query);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return rs;
	}
}
