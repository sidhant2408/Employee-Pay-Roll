package com.tint.cse.employeePay;

import java.sql.*;
import java.util.Scanner;

public class Main {
	public static void main(String... args) throws Exception {
		Conn connection = new Conn();
		Connection con = connection.startConnection();
		Functionality ob1 = new Functionality();

		Scanner sc = null;
		try {
			sc = new Scanner(System.in);
		} catch (Exception e) {
		}

		int flag = 0, options;
		while (flag == 0) {
			System.out.println("\n\t\t\t\t\t---Welcome to Employee Payroll System---\n\n" + "1. Create New Employee ID\t\t"
					+ "2. Employee Payroll Details\t\t" + "3. Get last employee details\t\t" + "4. Order by\n"
					+ "5. Highest Net Pay\t\t\t" + "6. Total Net Pay\t\t\t" + "7. Total Due Pay\t\t\t"
					+ "8. Total Number of Employees\n" + "9. Total Number of due pay\t\t" + "10. Group by\t\t\t\t"
					+ "11. Get details of employees in between a range of netpay\n"+"12.Modify duepay\t\t\t" +"13. Quit\n\nEnter choice:");
			options = sc.nextInt();
			sc.nextLine();
			if (options == 1) {
				String name, designation, gender;
				int contactNumber;
				float baseSalary, extraPay, ma, hra, due;

				System.out.println("Enter Name: ");
				name = sc.nextLine();
				System.out.println("Enter Designation: ");
				designation = sc.nextLine();
				System.out.println("Enter Contact Number: : ");
				contactNumber = sc.nextInt();
				sc.nextLine();
				System.out.println("Enter Gender: ");
				gender = sc.nextLine();
				System.out.println("Enter Base Salary: ");
				baseSalary = sc.nextFloat();
				sc.nextLine();
				System.out.println("Enter Extra Pay: ");
				extraPay = sc.nextFloat();
				sc.nextLine();
				System.out.println("Enter Due: ");
				due = sc.nextFloat();
				sc.nextLine();

				hra = baseSalary * 0.40f;
				ma = baseSalary * 0.15f;

				Emp ob = new Emp(name, contactNumber, baseSalary, hra, extraPay, ma, designation, gender);
				String inp_query = "INSERT INTO employeeinfo (EmpID,EmpName,Designation,ContactNumber,Gender,BaseSal,ExtraPay,HRA,MedicalAllow,DuePay,NetPay) "
						+ "VALUES(?,?,?,?,?,?,?,?,?,?,?)";
				try (PreparedStatement psd = con.prepareStatement(inp_query);) {
					psd.setInt(1, ob.getEmpId());
					psd.setString(2, name);
					psd.setString(3, designation);
					psd.setInt(4, contactNumber);
					psd.setString(5, gender);
					psd.setFloat(6, baseSalary);
					psd.setFloat(7, extraPay);
					psd.setFloat(8, hra);
					psd.setFloat(9, ma);
					psd.setFloat(10, due);
					psd.setFloat(11, ob.getSalaryObject().calculateNetPay());
					psd.executeUpdate();
				} catch (Exception e) {
					System.out.println(e.getMessage());
				}
				
			} else if (options == 2) {
				ResultSet rs = connection.getExecuteStatment("select * from employeeinfo;");
				ob1.printData(rs);
			}

			else if (options == 3) {
				ResultSet rs = ob1.detalisOfLastEmployee();
				ob1.printData(rs);
			}

			else if (options == 4) {
				System.out.println("1. Order by Net Pay\n2. Order by Due Pay\nEnter choice:");
				int choise = sc.nextInt();
				sc.nextLine();
				ResultSet rs = null;
				while (rs == null) {
					if (choise == 1) {
						rs = ob1.orderBy(1);
					} else if (choise == 2) {
						rs = ob1.orderBy(2);
					} else {
						System.out.println("Invalid Input!!");
					}
				}
				ob1.printData(rs);
			}

			else if (options == 5) {
				ResultSet rs = ob1.highestNetPay();
				ob1.printData(rs);
			}

			else if (options == 6) {
				System.out.println("Total Net Pay:");
				ResultSet rs = ob1.totalNetPay();
				ob1.printCount(rs);
			}

			else if (options == 7) {
				System.out.println("Total Due Pay:");
				ResultSet rs = ob1.totalDuePay();
				ob1.printCount(rs);
			}

			else if (options == 8) {
				System.out.println("Total Number of Employees:");
				ResultSet rs = ob1.totalNumberOfPerson();
				ob1.printCount(rs);
			}

			else if (options == 9) {
				System.out.println("Total Number of due payments:");
				ResultSet rs = ob1.totalNumberOfDuePay();
				ob1.printCount(rs);
			}

			else if (options == 10) {
				ResultSet rs = null;
				while (rs == null) {
					System.out.println("1. Group by Designation\n2. Group by Gender\nEnter choice:");
					int choise = sc.nextInt();
					sc.nextLine();
					rs = ob1.groupBy(choise);
					ob1.printData(rs);
				}
			}
			
			else if (options == 11) {
				float a, b;
				System.out.println("Enter floor value of range: ");
				a = sc.nextFloat();
				sc.nextLine();
				System.out.println("Enter ceil value of range: ");
				b = sc.nextFloat();
				sc.nextLine();
				ResultSet rs = ob1.rangeNetpay(a, b);
				ob1.printData(rs);
			}
			
			else if(options == 12) {
				int id;
				float amount;
				System.out.println("Enter Employee Id: ");id = sc.nextInt();sc.nextLine();
				System.out.println("Enter Amount: ");amount = sc.nextFloat();sc.nextLine();
				ob1.modifyDuePay(id, amount);
			}
			
			else if (options == 13) {
				System.out.println("----Thank You!!!----");
				flag = 1;
			}
		}
	}
}